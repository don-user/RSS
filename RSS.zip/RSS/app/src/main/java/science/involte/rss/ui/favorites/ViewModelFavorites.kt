package science.involte.rss.ui.favorites

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import science.involte.rss.room.database.RssEntity
import science.involte.rss.room.repository.LocalRssRepository

class ViewModelFavorites(application: Application): AndroidViewModel(application) {

    private val repositoryFavoritesRss = LocalRssRepository(application)

    val listFavoritesRss = repositoryFavoritesRss.getFavoritesRss().asLiveData()

    fun deleteFavoritesRss(item: RssEntity){

        viewModelScope.launch(Dispatchers.IO) {
            repositoryFavoritesRss.deleteItemFavoritesRss(item)
        }
    }
}