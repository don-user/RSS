package science.involte.rss.ui.news

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import science.involte.rss.databinding.FragmentNewsBinding
import science.involte.rss.ui.secondactivity.NewsRecyclerActivity
import science.involte.rss.utils.Constants.BREAKING_NEWS
import science.involte.rss.utils.Constants.EXTRA
import science.involte.rss.utils.Constants.GADGETS_NEWS
import science.involte.rss.utils.Constants.GAMES_NEWS
import science.involte.rss.utils.Constants.HARDWARE_NEWS
import science.involte.rss.utils.Constants.SOFTWARE_NEWS

class FragmentNews: Fragment() {

    private var fragmentNews: FragmentNewsBinding? = null
    private lateinit var binding: FragmentNewsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentNewsBinding.inflate(inflater, container, false)
        fragmentNews = binding

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        buttonsClick()
    }

    private fun buttonsClick() = with(binding){
        breakingButton.setOnClickListener {
            requireActivity().run {
                startActivity(Intent(this, NewsRecyclerActivity:: class.java).apply {
                    putExtra(EXTRA, BREAKING_NEWS)
                })
            }
        }

        hardwareButton.setOnClickListener {
            requireActivity().run {
                startActivity(Intent(this, NewsRecyclerActivity:: class.java).apply {
                    putExtra(EXTRA, HARDWARE_NEWS)
                })
            }
        }
        gadgetsButton.setOnClickListener {
            requireActivity().run {
                startActivity(Intent(this, NewsRecyclerActivity:: class.java).putExtra(EXTRA, GADGETS_NEWS))
            }
        }

        softwareButton.setOnClickListener {
            requireActivity().run {
                startActivity(Intent(this, NewsRecyclerActivity:: class.java).apply {
                    putExtra(EXTRA, SOFTWARE_NEWS)
                })
            }
        }

        gamesButton.setOnClickListener {
            requireActivity().run {
                startActivity(Intent(this, NewsRecyclerActivity:: class.java).apply {
                    putExtra(EXTRA, GAMES_NEWS)
                })
            }
        }
    }
}

