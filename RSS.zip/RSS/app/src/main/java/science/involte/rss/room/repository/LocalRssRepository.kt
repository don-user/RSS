package science.involte.rss.room.repository

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.Flow
import science.involte.rss.room.database.RssDatabase
import science.involte.rss.room.database.RssEntity

class LocalRssRepository(context: Context) {

    private val favoritesRss = RssDatabase.buildRssDatabase(context).rssDao()

    fun getFavoritesRss(): Flow<List<RssEntity>> {
        return favoritesRss.getListRssNews()
    }

    suspend fun insertFavoritesRssItem(item: RssEntity){
        favoritesRss.insertRssNewsItem(item)
    }

    suspend fun deleteItemFavoritesRss(item: RssEntity){
        favoritesRss.deleteItem(item)
    }

}